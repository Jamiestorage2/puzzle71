#!/bin/bash
#===============================================================================
# KeyHunt Smart Coordinator v3.8.0 - Installation Script
#===============================================================================
# This script installs all dependencies and builds KeyHunt from source.
#
# Usage:
#   ./install.sh              # Full installation (CPU only)
#   ./install.sh --gpu        # Full installation with GPU support
#   ./install.sh --deps-only  # Install dependencies only
#   ./install.sh --build-only # Build KeyHunt only (assumes deps installed)
#   ./install.sh --help       # Show help
#
# Requirements:
#   - Ubuntu 18.04+ / Debian 10+ (or compatible)
#   - sudo privileges
#   - Internet connection
#
# Version: 1.0.0
# Compatible with: KeyHunt Smart Coordinator v3.8.0
#===============================================================================

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COORDINATOR_VERSION="3.8.0"
LOG_FILE="${SCRIPT_DIR}/install.log"

# Default options
INSTALL_GPU=false
DEPS_ONLY=false
BUILD_ONLY=false
CUDA_CAPABILITY=""
SKIP_CONFIRM=false

#-------------------------------------------------------------------------------
# Helper Functions
#-------------------------------------------------------------------------------

print_header() {
    echo -e "${CYAN}"
    echo "==============================================================================="
    echo "$1"
    echo "==============================================================================="
    echo -e "${NC}"
}

print_step() {
    echo -e "${BLUE}[*]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[+]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

print_error() {
    echo -e "${RED}[X]${NC} $1"
}

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

check_root() {
    if [[ $EUID -eq 0 ]]; then
        print_error "Do not run this script as root. Use a regular user with sudo privileges."
        exit 1
    fi
}

check_sudo() {
    if ! sudo -v &>/dev/null; then
        print_error "This script requires sudo privileges."
        exit 1
    fi
}

detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$NAME
        VERSION=$VERSION_ID
    else
        print_error "Cannot detect operating system. /etc/os-release not found."
        exit 1
    fi

    print_step "Detected OS: $OS $VERSION"
}

detect_cuda() {
    if command -v nvcc &>/dev/null; then
        CUDA_VERSION=$(nvcc --version | grep "release" | awk '{print $6}' | cut -d',' -f1)
        print_success "CUDA detected: $CUDA_VERSION"
        return 0
    elif [ -d /usr/local/cuda ]; then
        print_success "CUDA directory found at /usr/local/cuda"
        return 0
    else
        return 1
    fi
}

detect_gpu() {
    if command -v nvidia-smi &>/dev/null; then
        GPU_INFO=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1)
        if [ -n "$GPU_INFO" ]; then
            print_success "NVIDIA GPU detected: $GPU_INFO"
            return 0
        fi
    fi
    return 1
}

show_help() {
    echo "KeyHunt Smart Coordinator v${COORDINATOR_VERSION} - Installation Script"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  --gpu              Enable GPU/CUDA support"
    echo "  --deps-only        Install dependencies only, don't build"
    echo "  --build-only       Build KeyHunt only (assumes dependencies installed)"
    echo "  --ccap <value>     CUDA compute capability (e.g., 75 for RTX 2080)"
    echo "  -y, --yes          Skip confirmation prompts"
    echo "  -h, --help         Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0                 # Install everything (CPU only)"
    echo "  $0 --gpu           # Install with GPU support"
    echo "  $0 --gpu --ccap 86 # GPU support with specific compute capability"
    echo ""
    echo "Common CUDA Compute Capabilities:"
    echo "  50 - GTX 750, 750 Ti"
    echo "  61 - GTX 1050, 1060, 1070, 1080"
    echo "  70 - Tesla V100"
    echo "  75 - RTX 2060, 2070, 2080, Quadro RTX"
    echo "  80 - A100"
    echo "  86 - RTX 3060, 3070, 3080, 3090"
    echo "  89 - RTX 4090"
    echo ""
}

#-------------------------------------------------------------------------------
# Installation Functions
#-------------------------------------------------------------------------------

install_system_dependencies() {
    print_header "Installing System Dependencies"

    log "Installing system dependencies"

    print_step "Updating package lists..."
    sudo apt-get update >> "$LOG_FILE" 2>&1

    print_step "Installing build essentials..."
    sudo apt-get install -y \
        build-essential \
        g++-8 \
        gcc-8 \
        make \
        git \
        wget \
        curl \
        >> "$LOG_FILE" 2>&1
    print_success "Build tools installed"

    print_step "Installing GMP library (for big integer math)..."
    sudo apt-get install -y libgmp-dev >> "$LOG_FILE" 2>&1
    print_success "GMP library installed"

    print_step "Installing GTK3 and dependencies (for GUI)..."
    sudo apt-get install -y \
        libgtk-3-dev \
        libgirepository1.0-dev \
        gir1.2-gtk-3.0 \
        libcairo2-dev \
        pkg-config \
        >> "$LOG_FILE" 2>&1
    print_success "GTK3 installed"

    print_step "Installing Python 3 and pip..."
    sudo apt-get install -y \
        python3 \
        python3-pip \
        python3-venv \
        python3-dev \
        >> "$LOG_FILE" 2>&1
    print_success "Python 3 installed"

    log "System dependencies installed successfully"
}

install_python_dependencies() {
    print_header "Installing Python Dependencies"

    log "Installing Python dependencies"

    print_step "Upgrading pip..."
    python3 -m pip install --upgrade pip >> "$LOG_FILE" 2>&1

    print_step "Installing PyGObject (GTK bindings)..."
    python3 -m pip install PyGObject >> "$LOG_FILE" 2>&1
    print_success "PyGObject installed"

    print_step "Installing pycairo..."
    python3 -m pip install pycairo >> "$LOG_FILE" 2>&1
    print_success "pycairo installed"

    print_step "Installing requests..."
    python3 -m pip install requests >> "$LOG_FILE" 2>&1
    print_success "requests installed"

    print_step "Installing BeautifulSoup4..."
    python3 -m pip install beautifulsoup4 >> "$LOG_FILE" 2>&1
    print_success "beautifulsoup4 installed"

    print_step "Installing lxml (parser for BeautifulSoup)..."
    python3 -m pip install lxml >> "$LOG_FILE" 2>&1
    print_success "lxml installed"

    log "Python dependencies installed successfully"
}

install_cuda() {
    print_header "CUDA Installation"

    if detect_cuda; then
        print_success "CUDA is already installed"
        return 0
    fi

    print_warning "CUDA not found. Installing CUDA toolkit..."
    print_step "This may take a while..."

    # Download and install CUDA keyring
    wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2004/x86_64/cuda-keyring_1.1-1_all.deb \
        -O /tmp/cuda-keyring.deb >> "$LOG_FILE" 2>&1
    sudo dpkg -i /tmp/cuda-keyring.deb >> "$LOG_FILE" 2>&1

    sudo apt-get update >> "$LOG_FILE" 2>&1
    sudo apt-get install -y cuda-toolkit-12-0 >> "$LOG_FILE" 2>&1

    # Add CUDA to PATH
    if ! grep -q "cuda" ~/.bashrc; then
        echo 'export PATH=/usr/local/cuda/bin:$PATH' >> ~/.bashrc
        echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH' >> ~/.bashrc
    fi

    export PATH=/usr/local/cuda/bin:$PATH
    export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH

    print_success "CUDA toolkit installed"
    print_warning "You may need to log out and back in for PATH changes to take effect"
}

build_keyhunt() {
    print_header "Building KeyHunt"

    log "Building KeyHunt"

    cd "$SCRIPT_DIR"

    # Clean previous build
    print_step "Cleaning previous build..."
    make clean >> "$LOG_FILE" 2>&1 || true
    rm -rf obj/ >> "$LOG_FILE" 2>&1 || true

    # Create object directories
    mkdir -p obj/GPU obj/hash

    if [ "$INSTALL_GPU" = true ]; then
        print_step "Building KeyHunt with GPU support..."

        # Detect compute capability if not specified
        if [ -z "$CUDA_CAPABILITY" ]; then
            # Try to auto-detect
            if command -v nvidia-smi &>/dev/null; then
                # Get compute capability from nvidia-smi
                CUDA_CAPABILITY=$(nvidia-smi --query-gpu=compute_cap --format=csv,noheader 2>/dev/null | head -1 | tr -d '.')
            fi

            if [ -z "$CUDA_CAPABILITY" ]; then
                print_warning "Could not auto-detect CUDA compute capability"
                print_warning "Using default: 75 (RTX 20 series)"
                CUDA_CAPABILITY="75"
            else
                print_success "Auto-detected CUDA compute capability: ${CUDA_CAPABILITY:0:1}.${CUDA_CAPABILITY:1:1}"
            fi
        fi

        make gpu=1 CCAP=$CUDA_CAPABILITY >> "$LOG_FILE" 2>&1

        if [ -f KeyHunt ]; then
            print_success "KeyHunt built successfully with GPU support!"
        else
            print_error "Build failed. Check install.log for details."
            exit 1
        fi
    else
        print_step "Building KeyHunt (CPU only)..."
        make >> "$LOG_FILE" 2>&1

        if [ -f KeyHunt ]; then
            print_success "KeyHunt built successfully (CPU only)"
        else
            print_error "Build failed. Check install.log for details."
            exit 1
        fi
    fi

    # Create symlink for convenience
    if [ -f KeyHunt ]; then
        ln -sf KeyHunt keyhunt 2>/dev/null || true
    fi

    log "KeyHunt build completed"
}

verify_installation() {
    print_header "Verifying Installation"

    ERRORS=0

    # Check KeyHunt binary
    print_step "Checking KeyHunt binary..."
    if [ -f "$SCRIPT_DIR/KeyHunt" ]; then
        print_success "KeyHunt binary found"

        # Test execution
        if "$SCRIPT_DIR/KeyHunt" -h &>/dev/null; then
            print_success "KeyHunt executes correctly"
        else
            print_warning "KeyHunt may have runtime issues"
        fi
    else
        print_error "KeyHunt binary not found"
        ((ERRORS++))
    fi

    # Check Python dependencies
    print_step "Checking Python dependencies..."

    python3 -c "import gi; gi.require_version('Gtk', '3.0')" &>/dev/null && \
        print_success "PyGObject (GTK) OK" || { print_error "PyGObject missing"; ((ERRORS++)); }

    python3 -c "import cairo" &>/dev/null && \
        print_success "pycairo OK" || { print_error "pycairo missing"; ((ERRORS++)); }

    python3 -c "import requests" &>/dev/null && \
        print_success "requests OK" || { print_error "requests missing"; ((ERRORS++)); }

    python3 -c "from bs4 import BeautifulSoup" &>/dev/null && \
        print_success "beautifulsoup4 OK" || { print_error "beautifulsoup4 missing"; ((ERRORS++)); }

    # Check coordinator script
    print_step "Checking coordinator script..."
    if [ -f "$SCRIPT_DIR/keyhunt_smart_coordinator_v3.8.0.py" ]; then
        print_success "Coordinator v3.8.0 found"
    else
        print_warning "Coordinator v3.8.0 not found in current directory"
    fi

    # Check backup tool
    if [ -f "$SCRIPT_DIR/backup_database.py" ]; then
        print_success "Backup tool found"
    fi

    echo ""
    if [ $ERRORS -eq 0 ]; then
        print_success "All verifications passed!"
    else
        print_error "$ERRORS verification(s) failed"
    fi

    return $ERRORS
}

create_launcher() {
    print_header "Creating Launcher Script"

    LAUNCHER="$SCRIPT_DIR/start_keyhunt.sh"

    cat > "$LAUNCHER" << 'LAUNCHER_EOF'
#!/bin/bash
# KeyHunt Smart Coordinator Launcher
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Check if KeyHunt binary exists
if [ ! -f "KeyHunt" ]; then
    echo "Error: KeyHunt binary not found. Please run install.sh first."
    exit 1
fi

# Launch coordinator
echo "Starting KeyHunt Smart Coordinator v3.8.0..."
python3 keyhunt_smart_coordinator_v3.8.0.py "$@"
LAUNCHER_EOF

    chmod +x "$LAUNCHER"
    print_success "Created launcher: start_keyhunt.sh"
}

create_requirements_file() {
    print_step "Creating requirements.txt..."

    cat > "$SCRIPT_DIR/requirements.txt" << EOF
# KeyHunt Smart Coordinator v3.8.0 - Python Dependencies
# Install with: pip3 install -r requirements.txt

PyGObject>=3.36.0
pycairo>=1.20.0
requests>=2.25.0
beautifulsoup4>=4.9.0
lxml>=4.6.0
EOF

    print_success "Created requirements.txt"
}

#-------------------------------------------------------------------------------
# Main Script
#-------------------------------------------------------------------------------

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --gpu)
            INSTALL_GPU=true
            shift
            ;;
        --deps-only)
            DEPS_ONLY=true
            shift
            ;;
        --build-only)
            BUILD_ONLY=true
            shift
            ;;
        --ccap)
            CUDA_CAPABILITY="$2"
            shift 2
            ;;
        -y|--yes)
            SKIP_CONFIRM=true
            shift
            ;;
        -h|--help)
            show_help
            exit 0
            ;;
        *)
            print_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Start installation
clear
print_header "KeyHunt Smart Coordinator v${COORDINATOR_VERSION} Installer"

echo "Installation Options:"
echo "  - GPU Support: $([ "$INSTALL_GPU" = true ] && echo "Yes" || echo "No")"
echo "  - Dependencies Only: $([ "$DEPS_ONLY" = true ] && echo "Yes" || echo "No")"
echo "  - Build Only: $([ "$BUILD_ONLY" = true ] && echo "Yes" || echo "No")"
[ -n "$CUDA_CAPABILITY" ] && echo "  - CUDA Capability: $CUDA_CAPABILITY"
echo ""

# Initialize log
echo "Installation started at $(date)" > "$LOG_FILE"
log "Options: GPU=$INSTALL_GPU, DEPS_ONLY=$DEPS_ONLY, BUILD_ONLY=$BUILD_ONLY"

# Check environment
check_root
check_sudo
detect_os

# Detect hardware
if [ "$INSTALL_GPU" = true ]; then
    detect_gpu || print_warning "No NVIDIA GPU detected. GPU build may not work correctly."
fi

# Confirmation
if [ "$SKIP_CONFIRM" = false ]; then
    echo ""
    read -p "Continue with installation? [Y/n] " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]] && [[ ! -z $REPLY ]]; then
        echo "Installation cancelled."
        exit 0
    fi
fi

# Run installation steps
if [ "$BUILD_ONLY" = false ]; then
    install_system_dependencies
    install_python_dependencies

    if [ "$INSTALL_GPU" = true ]; then
        install_cuda
    fi
fi

if [ "$DEPS_ONLY" = false ]; then
    build_keyhunt
fi

# Create helper files
create_requirements_file
create_launcher

# Verify
verify_installation
VERIFY_RESULT=$?

# Final message
print_header "Installation Complete!"

echo "Quick Start:"
echo "  1. Run the coordinator:"
echo "     ./start_keyhunt.sh"
echo "     OR"
echo "     python3 keyhunt_smart_coordinator_v3.8.0.py"
echo ""
echo "  2. To restore a database backup:"
echo "     python3 backup_database.py --restore backup_file.tar.gz"
echo ""
echo "  3. To create a backup:"
echo "     python3 backup_database.py"
echo ""

if [ "$INSTALL_GPU" = true ]; then
    echo "GPU Notes:"
    echo "  - If GPU is not detected, you may need to reboot"
    echo "  - Check CUDA with: nvidia-smi"
    echo ""
fi

echo "Log file: $LOG_FILE"
echo ""

exit $VERIFY_RESULT
